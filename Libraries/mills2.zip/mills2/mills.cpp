#include "mills.h"
#include "Arduino.h"

mills::mills(unsigned long tempo){
interval = tempo;
previousMillis = 0;
_status = false;
}

mills::mills(){
	previousMillis = 0;
	_status = false;
	_play = true;
}

boolean mills::verifica(){
//Serial.print((millis() - previousMillis));
//Serial.println(interval);
 if (((millis() - previousMillis) >= interval) && _status) {
  return true;
 }
 return false;

}

void mills::reset(){
previousMillis = millis();
_restante = interval;
_decorrido =0;
}

void mills::setTime(unsigned long tempo){
interval = tempo;
}

void mills::on(){
_status = true;
}

void mills::off(){
_status = false;
}

unsigned long mills::decorrido(){
	_decorrido = (_status?millis() - previousMillis:_decorrido);
	return (_status?_decorrido:0);
}

void mills::play(){
	if(_status){return;}
	_status = true;
	//Serial.println(previousMillis);
	previousMillis = _status?(millis() - (interval - _restante)):previousMillis;
	//Serial.println(millis());
	//Serial.println(previousMillis);
	
}

void mills::pause(){
	_restante = _status?(interval-(millis() - previousMillis)):_restante;
	//Serial.println(restante);
	_status = false;
}

int mills::segundos(){
	return segundos(false);
}

int mills::segundos(bool final){
	return !final?((_status?decorrido():_decorrido) - (minutos()*60000))/1000: (interval-(minutos(true)*60000))/1000;
}

int mills::minutosRestante(){
	
	unsigned long restante = interval-(millis() - previousMillis);
	return (_status?restante:_restante)/1000/60;
}
int mills::segundosRestante(){
	unsigned long restante = interval-(millis() - previousMillis);
	return ((_status?restante:_restante) - (minutosRestante()*60000))/1000;
}
int mills::minutos(){
	return minutos(false);
}

int mills::minutos(bool final){
	return (!final?(_status?decorrido():_decorrido):interval)/1000/60;
}

