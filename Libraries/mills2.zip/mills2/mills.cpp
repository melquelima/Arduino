#include "mills.h"
#include "Arduino.h"

mills::mills(unsigned long tempo){
interval = tempo;
previousMillis = 0;
_status = false;
}

mills::mills(){
previousMillis = 0;
_status = false;
}

boolean mills::verifica(){

 if (((millis() - previousMillis) >= interval) && _status) {
  return true;
 }
 return false;

}

void mills::reset(){
previousMillis = millis();
}

void mills::setTime(unsigned long tempo){
interval = tempo;
}

void mills::on(){
_status = true;
}

void mills::off(){
_status = false;
}

unsigned long mills::decorrido(){
return (_status?(millis() - previousMillis):0);
}



