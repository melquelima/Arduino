#include "mills.h"
#include "Arduino.h"

mills::mills(unsigned long tempo){
interval = tempo;
previousMillis = 0;
_status = false;
}

mills::mills(){
	previousMillis = 0;
	_status = false;
	_play = true;
}

boolean mills::verifica(){

 if (((millis() - previousMillis) >= interval) && _status) {
  return true;
 }
 return false;

}

void mills::reset(){
previousMillis = millis();
}

void mills::setTime(unsigned long tempo){
interval = tempo;
}

void mills::on(){
_status = true;
}

void mills::off(){
_status = false;
}

unsigned long mills::decorrido(){
	_decorrido = (_status?millis() - previousMillis:_decorrido);
	return (_status?_decorrido:0);
}

void mills::play(){
	previousMillis = millis() - (interval - restante);
	Serial.println(millis());
	Serial.println(previousMillis);
	_status = true;
}

void mills::pause(){
	restante = interval-(millis() - previousMillis);
	Serial.println(restante);
	_status = false;
}

int mills::segundos(){
	return segundos(false);
}

int mills::segundos(bool final){
	return !final?((_status?decorrido():_decorrido) - (minutos()*60000))/1000: (interval-(minutos(true)*60000))/1000;
}

int mills::minutos(){
	return minutos(false);
}

int mills::minutos(bool final){
	return (!final?(_status?decorrido():_decorrido):interval)/1000/60;
}

