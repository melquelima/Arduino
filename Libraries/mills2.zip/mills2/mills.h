#ifndef mills_h
#define mills_h
#include "Arduino.h"

class mills{
public:
mills(unsigned long tempo);
mills();
void setTime(unsigned long tempo);
boolean verifica();
void reset();
unsigned long decorrido();
void on();
void off();

private:
boolean _status;
unsigned long previousMillis;
unsigned long interval;


};

#endif