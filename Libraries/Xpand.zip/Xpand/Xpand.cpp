#include "Arduino.h"
#include "Xpand.h"

#include "SoftwareSerial"

Xpand::Xpand(int pino){
  SoftwareSerial mySerial(100, pino);
}
void Xpand::comando(char* str){
for(int i = 0; i<=7; i++){
  array[i] = str[i]-48;
}
  execute();
}

void Xpand::execute(){
 digitalWrite(latch,LOW);
     for (int x = 0; x <= 7; x++) {
      digitalWrite(clock,LOW);
      
      if (array[x]) {
        digitalWrite(data,HIGH);
      } else {
        digitalWrite(data,LOW);
      }
      
      digitalWrite(clock,HIGH);
    }    
    
    digitalWrite(latch,HIGH);
  
  
}


void Xpand::reset(){
 for(int i = 0; i<=7; i++)
 array[i] = 0;
 execute();
}

void Xpand::toogle(int comando){
  array[comando-1] = !array[comando-1];
  execute();
}

void Xpand::sequencia(int direc, int tempo){
  reset();
  
  if (direct){
  for(int i =0 i<=7;i++){
   toogle(i);
   delay(tempo);
    toogle(i); 
    }
  }else{
    for(int i =7; i<=0;i--){
   toogle(i);
   delay(tempo);
    toogle(i); 
  }
  
}