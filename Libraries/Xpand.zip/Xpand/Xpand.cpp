#include "Arduino.h"
#include "Xpand.h"


Xpand::Xpand(int latch, int clock, int data,int qtd){
	_qtd = qtd;
	_latch = latch;
	_clock = clock;
	_data = data;
	execute();
}
void Xpand::comando(char* str){
for(int i = 0; i<=7; i++){
  array[i] = str[i]-48;
}
  execute();
}

void Xpand::execute(){
	for (int y = 1; y <= _qtd; y++) {
		digitalWrite(_latch,0);
			for (int x = 0; x <= 7; x++) {
				digitalWrite(_clock,0);
				digitalWrite(_data,(array[x + ((y-1)*8)]?1:0));
				digitalWrite(_clock,1);
			}    
		digitalWrite(_latch,1);
	}
}


void Xpand::reset(){
	for(int i = 0; i<=(_qtd*8)-1; i++)
	array[i] = 0;
	execute();
}

void Xpand::toogle(int comando){
  array[comando-1] = !array[comando-1];
  execute();
}