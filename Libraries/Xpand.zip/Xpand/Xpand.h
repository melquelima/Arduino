#ifndef Xpand_h
#define Xpand_h

#include "Arduino.h"

class Xpand
{
  public:
    Xpand(int pino);
    void comando(char* str);
    void reset();
    void toogle(int comando);
    void sequencia(int direc, int tempo);
  private:
  int array[8]={0,0,0,0,0,0,0,0};
};
#endif