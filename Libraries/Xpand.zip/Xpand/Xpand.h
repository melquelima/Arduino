#ifndef Xpand_h
#define Xpand_h

#include "Arduino.h"

class Xpand
{
  public:
    Xpand(int latch, int clock, int data,int qtd);
    void comando(char* str);
    void reset();
    void toogle(int comando);
    void sequencia(int direc, int tempo);
    void execute();
  private:
	  int array[64];
	  int _qtd;
    int _latch;
    int _clock;
    int _data;
};
#endif