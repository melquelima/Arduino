#include "pcfXpand.h"
#include "Arduino.h"
#include "Wire.h"

pcfXpand::pcfXpand(int end, int prm){
_end = end;
_estado = prm;
Wire.begin();
}
  

bool pcfXpand::begin(char comando){
	_modo = comando;

	//Comando = 'A' - > inicia com tudo 1
	//Comando = '*' - > inicia com tudo 0

	for (int i=0;i<=7;i++)numero[i] = (_modo == 'A'?1:0);

	Wire.beginTransmission(_end);

	if(_estado == OUTPUT){
		Wire.write(_modo == 'A'?B1111111:B00000000);
	}
	return (Wire.endTransmission()==0?true:false);
}


bool pcfXpand::begin(){
	return begin('*');
}

void pcfXpand::reset(){

if(_estado){
for (int i=0;i<=7;i++){
	numero[i] = (_modo=='A'?1:0);
	digWrite(i,numero[i]);
}
}
}
int pcfXpand::digRead(int y){

if (_estado == INPUT){
	Wire.requestFrom(_end,1);
  	if(Wire.available())  {
  	 byte x = Wire.read();
	//Serial.println(x,BIN);
   	 for (int j = 0; j <= 7; j++){
    	  if (!(x & (1 << j))) {if (j == y){return true;}} 
   	 } 
    
 	 }
 	  return false; 
	}else{
		return (numero[y]?true:false);
	}
}

void pcfXpand::digWrite(int pt, int valor){

 numero[pt] = valor;
    int num =
    (numero[0]*1) +     (numero[1]*2) + 
    (numero[2]*4) +     (numero[3]*8) + 
    (numero[4]*16) +    (numero[5]*32) + 
    (numero[6]*64) +    (numero[7]*128);

  Wire.beginTransmission(_end);
  Wire.write(num);
  Wire.endTransmission();

}


