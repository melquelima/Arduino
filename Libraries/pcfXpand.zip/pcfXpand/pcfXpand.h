#ifndef pcfXpand_h
#define pcfXpand_h
#include "Arduino.h"
#include <Wire.h>


class pcfXpand{
public:
pcfXpand(int end, int prm);
int digRead(int y);
void digWrite(int pt, int valor);
bool begin(char comando);
bool begin();
void reset();
private:
int _estado;
char _modo;
int _end;
int numero[8];
};

#endif